import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
array=data
flag=false
  constructor() { }

  ngOnInit() {
  }

  setFlag()
  {
    this.flag=true
  }
}
