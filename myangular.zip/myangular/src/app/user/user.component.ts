import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'

@Component({
  selector: 'app-createuser',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
array=data
accNum: number;
successflag=false
  constructor() { }

  ngOnInit() {
  }

  add(form)
  {
    this.accNum=Math.floor(Math.random() * 100) + 1 
    this.array.push({
      accNum: this.accNum, 
      name: form.name, 
      phone: form.phone, 
      email: form.email, 
      balance: 0})
    this.successflag=true;
  }
}
