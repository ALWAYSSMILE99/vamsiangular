import { SearchingPipe } from './searching.pipe';

describe('SearchingPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchingPipe();
    expect(pipe).toBeTruthy();
  });
});
